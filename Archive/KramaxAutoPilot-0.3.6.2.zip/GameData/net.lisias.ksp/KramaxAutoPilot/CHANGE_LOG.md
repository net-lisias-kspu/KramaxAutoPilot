# KramaxAutoPilot /L :: Change Log

* 2018-1011: 0.3.6.2 (Lisias) for KSP 1.4.1+; 1.5
	+ Some code optizations and compliance
	+ Miscellaneous code fixes.
	+ Adding KSPe facilities
		- Data files
		- Logging 
	+ Flight Plans reorganized and documented
	+ Flight Plan Window now have a scrollbar
	+ Make the CDI moveable
* 2018-1004: 0.3.5.1 (Lisias) for KSP 1.1 PRE-RELEASE
	+ Internship Pre Release - Not that much to see here, just wetting my feet.
* 2018-0419: 0.3.5 (linuxgurugamer) for KSP 1.4.1
	+ Updated for 1.4.1
	+ Added support for the Clickthrough blocker
	+ Added support for the Toolbar Controller
* 2017-1013: 0.3.4.0 (linuxgurugamer) for KSP 1.4.1
	+ Fix for Heading hold not working., thanks @DavidShade
	+ added extras directory and flight plans
* 2016-1019: 0.3.2-beta (linuxgurugamer) for KSP 1.3 PRE-RELEASE
	+ No changelog provided
* 2017-0530: 0.3.2.3 (linuxgurugamer) for KSP 1.3
	+ Updated for 1.3
* 2016-1129: 0.3.2.2 (linuxgurugamer) for KSP 1.1
	+ Added code to put version into assembly version info
* 2016-1102: 0.3.2.1 (linuxgurugamer) for KSP 1.1
	+ No changelog provided
* 2016-1026: 0.3.2 (linuxgurugamer) for KSP 1.1
	+ No changelog provided
* 2016-0503: 0.3.1 (linuxgurugamer) for KSP 1.1
	+ recompiled for 1.1.2
	+ Added code from TedThompson to fix nullref
* 2016-0414: 0.3 (linuxgurugamer) for KSP 1.1 PRE-RELEASE
	+ Beta for 1.1
	+ Use at your own risk
	+ Source code is updated
