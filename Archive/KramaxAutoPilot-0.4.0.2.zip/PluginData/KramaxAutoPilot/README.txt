Kramax AutoPilot User Flight Plans

This is where you put your Custom Flight Plans. Each file will be read
in Alphabetical Order (ignoring case, and ordering numbers as a
human would do: "1, 2, 11").

This is also where your "_FlightPlans.cfg" file will be persisted. 
Please note that all plans from all your custom files will be merged 
to this file, as well any runtime plan you create. Any alterations
from that plans will preserved on this file without changing the original.
By deleting the plan from the user interface, it will be restored from
the original file contents.

The "_FlightPlans.cfg" file will be overwritten every time, but none of
the others.
